﻿// Custom JavaScript for Municipality Management System

// Wait for document to be fully loaded
$(document).ready(function () {
    // Initialize tooltips (if using Bootstrap tooltips)
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });

    // Initialize date pickers with default format
    $('input[type="date"]').each(function () {
        // If you want to use a date picker plugin instead of the browser default
        // You would initialize it here
    });

    // Add confirmation to delete buttons
    $('.btn-danger[asp-action="Delete"]').click(function (e) {
        if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) {
            e.preventDefault();
        }
    });

    // Custom form validation messages
    $.validator.setDefaults({
        errorClass: 'text-danger',
        highlight: function (element) {
            $(element).addClass('is-invalid');
        },
        unhighlight: function (element) {
            $(element).removeClass('is-invalid');
        }
    });
});
