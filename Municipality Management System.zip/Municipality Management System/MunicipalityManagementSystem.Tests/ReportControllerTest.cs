﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MunicipalityManagementSystem.Controllers;
using MunicipalityManagementSystem.Data;
using MunicipalityManagementSystem.Models;
using System;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace MunicipalityManagementSystem.Tests
{
    public class ReportControllerTests
    {
        private readonly ApplicationDbContext _context;
        private readonly ReportController _controller;

        public ReportControllerTests()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "MunicipalityManagement")
                .Options;
            _context = new ApplicationDbContext(options);
            _controller = new ReportController(_context);
        }

        [Fact]
        public async Task Index_ReturnsViewResult_WithReports()
        {
            // Arrange
            _context.Reports.Add(new Report { CitizenID = 1, ReportType = "Complaint", Details = "Details", SubmissionDate = DateTime.Now, Status = "Under Review" });
            await _context.SaveChangesAsync();

            // Act
            var result = await _controller.Index();

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<System.Collections.Generic.List<Report>>(viewResult.Model);
            Assert.Single(model);  // Ensure that there is at least one report
        }

        [Fact]
        public async Task Create_ReturnsRedirectToActionResult_WhenModelStateIsValid()
        {
            // Arrange
            var report = new Report { CitizenID = 1, ReportType = "Complaint", Details = "Test details" };

            // Act
            var result = await _controller.Create(report);

            // Assert
            var redirectToActionResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Index", redirectToActionResult.ActionName);
        }

        [Fact]
        public async Task ReviewReport_UpdatesStatus_ReturnsRedirectToActionResult_WhenModelStateIsValid()
        {
            // Arrange
            var report = new Report { CitizenID = 1, ReportType = "Complaint", Details = "Details", SubmissionDate = DateTime.Now, Status = "Under Review" };
            _context.Reports.Add(report);
            await _context.SaveChangesAsync();

            // Act
            var updatedReport = new Report { ReportID = report.ReportID, Status = "Resolved" };
            var result = await _controller.ReviewReport(report.ReportID, updatedReport);

            // Assert
            var redirectToActionResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Index", redirectToActionResult.ActionName);
            var updatedReportFromDb = await _context.Reports.FindAsync(report.ReportID);
            Assert.Equal("Resolved", updatedReportFromDb.Status);
        }

        [Fact]
        public async Task DeleteConfirmed_DeletesReport_ReturnsRedirectToActionResult()
        {
            // Arrange
            var report = new Report { CitizenID = 1, ReportType = "Complaint", Details = "Details", SubmissionDate = DateTime.Now, Status = "Under Review" };
            _context.Reports.Add(report);
            await _context.SaveChangesAsync();

            // Act
            var result = await _controller.DeleteConfirmed(report.ReportID);

            // Assert
            var redirectToActionResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Index", redirectToActionResult.ActionName);
            var deletedReport = await _context.Reports.FindAsync(report.ReportID);
            Assert.Null(deletedReport);  // Ensure the report has been deleted
        }
    }
}
