﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MunicipalityManagementSystem.Controllers;
using MunicipalityManagementSystem.Data;
using MunicipalityManagementSystem.Models;
using System;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace MunicipalityManagementSystem.Tests
{
    public class StaffControllerTests
    {
        private readonly ApplicationDbContext _context;
        private readonly StaffController _controller;

        public StaffControllerTests()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "MunicipalityManagement")
                .Options;
            _context = new ApplicationDbContext(options);
            _controller = new StaffController(_context);
        }

        [Fact]
        public async Task Index_ReturnsViewResult_WithStaff()
        {
            // Arrange
            _context.Staffs.Add(new Staff { FullName = "John Doe", Position = "Manager", Department = "Finance", Email = "john.doe@example.com", PhoneNumber = "1234567890", HireDate = DateTime.Now });
            await _context.SaveChangesAsync();

            // Act
            var result = await _controller.Index();

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<System.Collections.Generic.List<Staff>>(viewResult.Model);
            Assert.Single(model);  // Ensure that there is at least one staff member
        }

        [Fact]
        public async Task Create_ReturnsRedirectToActionResult_WhenModelStateIsValid()
        {
            // Arrange
            var staff = new Staff { FullName = "Jane Doe", Position = "Assistant", Department = "Public Works", Email = "jane.doe@example.com", PhoneNumber = "0987654321", HireDate = DateTime.Now };

            // Act
            var result = await _controller.Create(staff);

            // Assert
            var redirectToActionResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Index", redirectToActionResult.ActionName);
        }

        [Fact]
        public async Task Edit_UpdatesStaffDetails_ReturnsRedirectToActionResult_WhenModelStateIsValid()
        {
            // Arrange
            var staff = new Staff { FullName = "John Doe", Position = "Manager", Department = "Finance", Email = "john.doe@example.com", PhoneNumber = "1234567890", HireDate = DateTime.Now };
            _context.Staffs.Add(staff);
            await _context.SaveChangesAsync();

            // Act
            staff.FullName = "John Updated";
            var result = await _controller.Edit(staff.StaffID, staff);

            // Assert
            var redirectToActionResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Index", redirectToActionResult.ActionName);
            var updatedStaff = await _context.Staffs.FindAsync(staff.StaffID);
            Assert.Equal("John Updated", updatedStaff.FullName);  // Ensure the name was updated
        }

        [Fact]
        public async Task DeleteConfirmed_DeletesStaff_ReturnsRedirectToActionResult()
        {
            // Arrange
            var staff = new Staff { FullName = "Jane Doe", Position = "Assistant", Department = "Public Works", Email = "jane.doe@example.com", PhoneNumber = "0987654321", HireDate = DateTime.Now };
            _context.Staffs.Add(staff);
            await _context.SaveChangesAsync();

            // Act
            var result = await _controller.DeleteConfirmed(staff.StaffID);

            // Assert
            var redirectToActionResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Index", redirectToActionResult.ActionName);
            var deletedStaff = await _context.Staffs.FindAsync(staff.StaffID);
            Assert.Null(deletedStaff);  // Ensure the staff has been deleted
        }
    }
}
