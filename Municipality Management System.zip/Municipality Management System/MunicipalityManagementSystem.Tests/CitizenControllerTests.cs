﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MunicipalityManagementSystem.Controllers;
using MunicipalityManagementSystem.Data;
using MunicipalityManagementSystem.Models;
using System.Threading.Tasks;
using Xunit;

namespace MunicipalityManagementSystem.Tests
{
    public class CitizenControllerTests
    {
        private readonly ApplicationDbContext _context;
        private readonly CitizenController _controller;

        public CitizenControllerTests()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "MunicipalityManagement")
                .Options;
            _context = new ApplicationDbContext(options);
            _controller = new CitizenController(_context);
        }

        [Fact]
        public async Task Index_ReturnsViewWithCitizens_WhenCalled()
        {
            // Arrange
            _context.Citizens.Add(new Citizen { FullName = "John Doe", Email = "john.doe@example.com" });
            await _context.SaveChangesAsync();

            // Act
            var result = await _controller.Index();

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<System.Collections.Generic.List<Citizen>>(viewResult.Model);
            Assert.Single(model);  // Ensure that there is at least one citizen
        }

        [Fact]
        public async Task Create_Post_ValidCitizen_RedirectsToIndex_WhenModelIsValid()
        {
            // Arrange
            var citizen = new Citizen { FullName = "Jane Doe", Email = "jane.doe@example.com" };

            // Act
            var result = await _controller.Create(citizen);

            // Assert
            var redirectToActionResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Index", redirectToActionResult.ActionName);
        }

        [Fact]
        public async Task Details_ReturnsNotFoundWhenIdIsNull()
        {
            // Act
            var result = await _controller.Details(null);

            // Assert
            var notFoundResult = Assert.IsType<NotFoundResult>(result);
        }

        [Fact]
        public async Task DeleteConfirmed_RemovesCitizen_WhenCitizenExists()
        {
            // Arrange
            var citizen = new Citizen { FullName = "John Doe", Email = "john.doe@example.com" };
            _context.Citizens.Add(citizen);
            await _context.SaveChangesAsync();

            // Act
            var result = await _controller.DeleteConfirmed(citizen.CitizenID);

            // Assert
            var redirectToActionResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Index", redirectToActionResult.ActionName);
            var deletedCitizen = await _context.Citizens.FindAsync(citizen.CitizenID);
            Assert.Null(deletedCitizen);  // Ensure the citizen has been deleted
        }

        private ApplicationDbContext GetInMemoryDbContext()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "MunicipalityManagement")
                .Options;
            return new ApplicationDbContext(options);
        }
    }
}
