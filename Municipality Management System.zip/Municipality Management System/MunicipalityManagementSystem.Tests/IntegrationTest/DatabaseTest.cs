﻿using Microsoft.EntityFrameworkCore;
using MunicipalityManagementSystem.Data;
using MunicipalityManagementSystem.Models;
using System;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace MunicipalityManagementSystem.Tests
{
    public class DatabaseIntegrationTests
    {
        private readonly ApplicationDbContext _context;

        public DatabaseIntegrationTests()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "MunicipalityDB")
                .Options;
            _context = new ApplicationDbContext(options);
        }

        [Fact]
        public async Task FetchAllStaff_ReturnsList()
        {
            // Adding Staff members to the database
            _context.Staffs.Add(new Staff
            {
                FullName = "John Verwey",
                Position = "Senior Administrator",
                Department = "Administration",
                HireDate = new DateTime(2024, 6, 12),
                Email = "johnV@gmail.com",
                PhoneNumber = "083 443 4567"
            });

            _context.Staffs.Add(new Staff
            {
                FullName = "Melanie Schoonraad",
                Position = "Water Service Manager",
                Department = "Utilities",
                HireDate = new DateTime(2025, 4, 2),
                Email = "melSchoonraad@gmail.com",
                PhoneNumber = "0795534001"
            });

            await _context.SaveChangesAsync();

            // Fetching all staff members
            var staffList = await _context.Staffs.ToListAsync();

            Assert.Equal(2, staffList.Count);
            Assert.Contains(staffList, s => s.FullName == "John Verwey");
            Assert.Contains(staffList, s => s.FullName == "Melanie Schoonraad");
        }

        [Fact]
        public async Task AddStaff_RecordAppearsInDatabase()
        {
            var staff = new Staff
            {
                FullName = "Sarah Prins",
                Position = "Developer",
                Department = "IT",
                HireDate = DateTime.Now,
                Email = "sarah.prins@example.com",
                PhoneNumber = "0760000000"
            };

            _context.Staffs.Add(staff);
            await _context.SaveChangesAsync();

            // Verifying that the staff member was added to the database
            var exists = await _context.Staffs.AnyAsync(s => s.Email == "sarah.prins@example.com");
            Assert.True(exists);
        }

        [Fact]
        public async Task DeleteStaff_RemovesRecordFromDatabase()
        {
            var staff = new Staff
            {
                FullName = "Jemma Wakeford",
                Position = "Administrator",
                Department = "HR",
                HireDate = DateTime.Now,
                Email = "jemma.wakeford@example.com",
                PhoneNumber = "0821234567"
            };

            _context.Staffs.Add(staff);
            await _context.SaveChangesAsync();

            // Deleting the staff member
            _context.Staffs.Remove(staff);
            await _context.SaveChangesAsync();

            // Verifying the staff member has been deleted
            var exists = await _context.Staffs.AnyAsync(s => s.Email == "jemma.wakeford@example.com");
            Assert.False(exists);
        }
    }
}