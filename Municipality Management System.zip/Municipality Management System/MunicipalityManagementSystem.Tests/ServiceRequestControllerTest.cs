﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MunicipalityManagementSystem.Controllers;
using MunicipalityManagementSystem.Data;
using MunicipalityManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace MunicipalityManagementSystem.Tests
{
    public class ServiceRequestControllerTests
    {
        private ApplicationDbContext GetInMemoryDbContext()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            return new ApplicationDbContext(options);
        }

        [Fact]
        public async Task Index_ReturnsViewWithRequests()
        {
            var context = GetInMemoryDbContext();
            context.Citizens.Add(new Citizen { FullName = "Keagan van Rooyen", Address = "123 Street", PhoneNumber = "0123456789", Email = "keagan.vanrooyen@gmail.com" });
            await context.SaveChangesAsync();

            context.ServiceRequests.Add(new ServiceRequest { CitizenID = 1, ServiceType = "Water", RequestDate = DateTime.Now, Status = "Pending" });
            await context.SaveChangesAsync();

            var controller = new ServiceRequestController(context);
            var result = await controller.Index();

            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<List<ServiceRequest>>(viewResult.Model);
            Assert.Single(model);
        }

        [Fact]
        public async Task Create_Post_ValidRequest_RedirectsToIndex()
        {
            var context = GetInMemoryDbContext();
            context.Citizens.Add(new Citizen { FullName = "Jane Doe", Address = "456 Road", PhoneNumber = "0987654321", Email = "jane@example.com" });
            await context.SaveChangesAsync();

            var controller = new ServiceRequestController(context);

            var request = new ServiceRequest
            {
                CitizenID = 1,
                ServiceType = "Electricity",
                Details = "Power outage in area"
            };

            var result = await controller.Create(request);

            var redirect = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Index", redirect.ActionName);
            Assert.Single(context.ServiceRequests);
        }

        [Fact]
        public async Task UpdateStatus_Post_ChangesStatus()
        {
            var context = GetInMemoryDbContext();
            context.Citizens.Add(new Citizen { FullName = "Test Citizen", Address = "Test Address", PhoneNumber = "000111222", Email = "test@email.com" });
            await context.SaveChangesAsync();

            var request = new ServiceRequest
            {
                CitizenID = 1,
                ServiceType = "Road Maintenance",
                Status = "Pending",
                RequestDate = DateTime.Now
            };
            context.ServiceRequests.Add(request);
            await context.SaveChangesAsync();

            var controller = new ServiceRequestController(context);
            var update = new ServiceRequest { RequestID = request.RequestID, Status = "In Progress" };

            var result = await controller.UpdateStatus(request.RequestID, update);

            var redirect = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Index", redirect.ActionName);
            Assert.Equal("In Progress", context.ServiceRequests.First().Status);
        }

        [Fact]
        public async Task DeleteConfirmed_RemovesRequest()
        {
            var context = GetInMemoryDbContext();
            var citizen = new Citizen { FullName = "Del Citizen", Address = "Del Address", PhoneNumber = "5555555", Email = "del@email.com" };
            context.Citizens.Add(citizen);
            await context.SaveChangesAsync();

            var request = new ServiceRequest { CitizenID = citizen.CitizenID, ServiceType = "Waste Collection", Status = "Pending", RequestDate = DateTime.Now };
            context.ServiceRequests.Add(request);
            await context.SaveChangesAsync();

            var controller = new ServiceRequestController(context);
            var result = await controller.DeleteConfirmed(request.RequestID);

            var redirect = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Index", redirect.ActionName);
            Assert.Empty(context.ServiceRequests);
        }
    }
}
