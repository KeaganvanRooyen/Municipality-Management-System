﻿// Data/ApplicationDbContext.cs
using Microsoft.EntityFrameworkCore;
using MunicipalityManagementSystem.Models;

namespace MunicipalityManagementSystem.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Citizen> Citizens { get; set; }
        public DbSet<ServiceRequest> ServiceRequests { get; set; }
        public DbSet<Staff> Staffs { get; set; }
        public DbSet<Report> Reports { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure unique email for Citizen
            modelBuilder.Entity<Citizen>()
                .HasIndex(c => c.Email)
                .IsUnique();

            // Configure unique email for Staff
            modelBuilder.Entity<Staff>()
                .HasIndex(s => s.Email)
                .IsUnique();

            // Configure relationships
            modelBuilder.Entity<ServiceRequest>()
                .HasOne<Citizen>()
                .WithMany()
                .HasForeignKey(s => s.CitizenID);

            modelBuilder.Entity<Report>()
                .HasOne<Citizen>()
                .WithMany()
                .HasForeignKey(r => r.CitizenID);
        }
    }
}
