﻿// Models/ServiceRequest.cs
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MunicipalityManagementSystem.Models
{
    public class ServiceRequest
    {
        public int RequestID { get; set; }

        [Required(ErrorMessage = "Citizen is required")]
        [Display(Name = "Citizen")]
        public int CitizenID { get; set; }

        [Required(ErrorMessage = "Service Type is required")]
        [Display(Name = "Service Type")]
        public string ServiceType { get; set; }

        [Display(Name = "Request Date")]
        [DataType(DataType.Date)]
        public DateTime RequestDate { get; set; } = DateTime.Now;

        [Required(ErrorMessage = "Status is required")]
        public string Status { get; set; } = "Pending";

        [Display(Name = "Details")]
        public string Details { get; set; }

        [ForeignKey("CitizenID")]
        public virtual Citizen Citizen { get; set; }
    }
}



