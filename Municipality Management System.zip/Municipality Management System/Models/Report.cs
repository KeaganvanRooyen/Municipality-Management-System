﻿// Models/Report.cs
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MunicipalityManagementSystem.Models
{
    public class Report
    {
        public int ReportID { get; set; }

        [Required(ErrorMessage = "Citizen is required")]
        [Display(Name = "Citizen")]
        public int CitizenID { get; set; }

        [Required(ErrorMessage = "Report Type is required")]
        [Display(Name = "Report Type")]
        public string ReportType { get; set; }

        [Required(ErrorMessage = "Details are required")]
        public string Details { get; set; }

        [Display(Name = "Submission Date")]
        [DataType(DataType.Date)]
        public DateTime SubmissionDate { get; set; } = DateTime.Now;

        [Required(ErrorMessage = "Status is required")]
        public string Status { get; set; } = "Under Review";

        [ForeignKey("CitizenID")]
        public virtual Citizen Citizen { get; set; }
    }
}
