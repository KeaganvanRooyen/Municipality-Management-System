﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MunicipalityManagementSystem.Data;
using MunicipalityManagementSystem.Models;
using System.Linq;
using System.Threading.Tasks;
using Xunit;
using Moq;

namespace MunicipalityManagementSystem.Controllers
{
    public class CitizenController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CitizenController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Citizen
        public async Task<IActionResult> Index()
        {
            var citizens = await _context.Citizens.ToListAsync();
            return View(citizens);
        }

        // GET: Citizen/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
                return NotFound();

            var citizen = await _context.Citizens.FindAsync(id);

            return citizen == null ? NotFound() : View(citizen);
        }

        // GET: Citizen/Create
        public IActionResult Create() => View();

        // POST: Citizen/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("FullName,Address,PhoneNumber,Email,DateOfBirth")] Citizen citizen)
        {
            if (!ModelState.IsValid)
                return View(citizen);

            citizen.RegistrationDate = DateTime.Now;
            _context.Citizens.Add(citizen);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: Citizen/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
                return NotFound();

            var citizen = await _context.Citizens.FindAsync(id);
            return citizen == null ? NotFound() : View(citizen);
        }

        // POST: Citizen/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CitizenID,FullName,Address,PhoneNumber,Email,DateOfBirth,RegistrationDate")] Citizen citizen)
        {
            if (id != citizen.CitizenID)
                return NotFound();

            if (!ModelState.IsValid)
                return View(citizen);

            try
            {
                _context.Update(citizen);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CitizenExists(citizen.CitizenID))
                    return NotFound();
                else
                    throw;
            }
            return RedirectToAction(nameof(Index));
        }

        // GET: Citizen/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
                return NotFound();

            var citizen = await _context.Citizens.FindAsync(id);
            return citizen == null ? NotFound() : View(citizen);
        }

        // POST: Citizen/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var citizen = await _context.Citizens.FindAsync(id);
            if (citizen != null)
            {
                _context.Citizens.Remove(citizen);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        private bool CitizenExists(int id) => _context.Citizens.Any(e => e.CitizenID == id);
    }
}